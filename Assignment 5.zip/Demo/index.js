const express = require('express');
const mongodb = require('mongodb');
const port=3000;
const path = require('path');
const mongoose = require('mongoose');

mongoose.connect('mongodb.//localhost/Demo');
let itemdb = mongoose.connection;

//Check for connection
itemdb.once('open', function(){
  console.log('connected to mongodb');
});

//Check for database errors
itemdb.on('error', function(err){
  console.log(err);
});

// Initialise app
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//Load View Engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
/**
 * function which creates a Connection to MongoDB. Retries every 3 seconds if no connection could be established.
 */
async function connectMongoDB() {
    try {
        app.locals.dbConnection = await mongodb.MongoClient.connect("mongodb://localhost:27017", { useNewUrlParser: true });
        app.locals.db = await app.locals.dbConnection.db("itemdb");
       console.log("Using db: " + app.locals.db.databaseName);
    }
    catch (error) {
        console.dir(error)
        setTimeout(connectMongoDb, 3000)
    }
}
//Start connecting
connectMongoDB()

//Make all Files stored in Folders in "src" accessible over localhost:3000/public
app.use('/src', express.static(__dirname + '/src'))

//Share jquery over the server
app.use('/jquery', express.static(__dirname + '/node_modules/jquery/dist'))

//Share leaflet over the server
app.use('/leaflet', express.static(__dirname + '/node_modules/leaflet/dist'))

//Send index.html on request to "/"
app.get('/', (req,res) => {
    res.sendFile(__dirname + '/index.html')
})

//Get-Request to /hello will be answerde with "Hello World"
app.get('/hello', (req, res) => {
    res.send('Hello World')
})

// Pug Request
app.get('/pug', (req, res) => {
  let geojsonPoints = [
    {
    id: 1,
    title:'Point One'
    }
  ];
  res.render('geojsonPoints',{
    title: 'Favorites',
    });
});

// Add Route
app.get('/items/points', (req, res) =>{
  res.render('itemdb', {
    title: 'Added Points'
  });
});

//Returns all items stored in collection items
app.get("/item", (req,res) => {
    //Search for all items in mongodb
    app.locals.db.collection('items').find({}).toArray((error, result) => {
        if (error) {
            console.dir(error);
        }
        res.json(result);
    });
});

//Handler for Post requests to "/item"
app.post("/item", (req, res) => {
    // insert item
    console.log("insert item " + JSON.stringify(req.body));
    app.locals.db.collection('items').insertOne(req.body, (error, result) => {
        if (error) {
            console.dir(error);
        }
        res.json(result);
    });
});




// listen on port 3000
app.listen(port,
    () => console.log(`app listening at http://localhost:${port}`)
)
