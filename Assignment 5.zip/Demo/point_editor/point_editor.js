// jshint esversion: 6

const lat = 51.96;
const lon = 7.59;
const start_latlng = [lat, lon];




var map = L.map("map").setView(start_latlng, 13);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 14,
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors",
    id: "osm"
}).addTo(map);


var drawnItems = L.featureGroup().addTo(map);

//Only the marker drawer is allowed
map.addControl( new L.Control.Draw({
    edit: {
        featureGroup: drawnItems,
        poly: {
            allowIntersection: false
        }
    },
    draw: {
        circle: false,
        marker: true,
        polyline: false,
        rectangle:false,
        circlemarker: false,
        point: false,
         polygon: false,
    }
}));

//If the draw is deleted the textarea will also be cleared
map.on("draw:deleted", function (event) {
    "use strict";
    deleteText();
});

//if there will be a new Polygon drawn, the old one will be deleted and the text area updated
map.on("draw:created", function (event) {
    "use strict";
    var layer = event.layer;
    drawnItems.clearLayers();
    drawnItems.addLayer(layer);

    deleteText();
    updateText();
});

//if the draw will be edited the textarea changes
map.on("draw:edited", function (event) {
    "use strict";
    deleteText();
    updateText();
});

/**
 * clears the Text area
 */
function deleteText(){
    "use strict";
    document.getElementById("geojsontextarea").value = "";
}
/**
 * creates a geojson text representation from the the drawnItems with a FeatureCollection as root element
 */
function updateText(){
    "use strict";
    document.getElementById("geojsontextarea").value = JSON.stringify(drawnItems.toGeoJSON());
}


/**
 * 
 */
function onChange(){
    "use strict";
    let value= document.getElementById("geojsontextarea").value;
    try{
        const json = JSON.parse(value);
        //regex of regular geojson
        const regex = /\s*{\s*"type"\s*:\s*"FeatureCollection"\s*,\s*"features"\s*:\s*\[\s*{\s*"type"\s*:\s*"Feature"\s*,\s*"properties"\s*:\s*{(\s*"[a-zA-z\d]"*\s*:\s*"[a-zA-z\d]"\s*,\s*)*(\s*"[a-zA-z\d]"*\s*:\s*"[a-zA-z\d]"\s*)?}\s*,\s*"geometry"\s*:\s*\{"type"\s*:\s*"Point"\s*,\s*"coordinates"\s*:\s*\[-?\d{1,2}(\.\d*)?\s*,\s*-?\d{1,3}(\.\d*)?\s*\]\s*\}\s*\}\s*\]\s*\}\s*/gi;
        if (regex.test(value)) {
            drawnItems.clearLayers();
           
            const marker= L.marker([json.features[0].geometry.coordinates[1],json.features[0].geometry.coordinates[0]]);
            marker.addTo(drawnItems)
           // marker.addTo(map)
            map.fitBounds(drawnItems.getBounds());
        } else {
            alert("No valid GeoJSON inserted");
        }
    }
    catch(e){
        console.log(e)
        alert("No valid GeoJSON inserted");
        }
}